import 'package:flutter/material.dart';
import 'screens/welcome_screen.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'screens/product_details_screen.dart';
import 'models/plant.dart';

void main() {
  runApp(const LeafyApp());
}

class LeafyApp extends StatelessWidget {
  const LeafyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Leafy',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        // Main color palette
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF8A9A5B),
          primary: const Color(0xFF8A9A5B),
          secondary: const Color(0xFF344735),
          surface: const Color(0xFFF7F6EF),
        ),
        scaffoldBackgroundColor: const Color(0xFFF7F6EF),
        fontFamily: 'Roboto',
        useMaterial3: true,
      ),
      initialRoute: '/',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (_) => const WelcomeScreen());
          case '/login':
            return MaterialPageRoute(builder: (_) => const LoginScreen());
          case '/home':
            return MaterialPageRoute(builder: (_) => const HomeScreen());
          case '/product':
            final plant = settings.arguments as Plant;
            return MaterialPageRoute(
              builder: (_) => ProductDetailsScreen(plant: plant),
            );
          default:
            return MaterialPageRoute(builder: (_) => const WelcomeScreen());
        }
      },
    );
  }
}
