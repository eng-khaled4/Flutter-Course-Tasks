import 'package:flutter/material.dart';
import '../models/plant.dart';

/// Home Screen - Main browsing screen with categories and plant grid
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // Color constants
  static const Color sageGreen = Color(0xFF8A9A5B);
  static const Color softCream = Color(0xFFF7F6EF);
  static const Color darkGreen = Color(0xFF344735);

  // Track which category tab is selected
  int _selectedCategoryIndex = 0;

  // Track which bottom nav item is selected
  int _bottomNavIndex = 0;

  // ── Category list ──
  final List<String> categories = [
    'All',
    'Indoor',
    'Outdoor',
    'Succulents',
    'Herbs',
  ];

  // ── Dummy plant data ──
  final List<Plant> allPlants = const [
    Plant(
      id: '1',
      name: 'Monstera Deliciosa',
      category: 'Indoor',
      price: 45.99,
      imageUrl:
          'https://images.unsplash.com/photo-1614594975525-e45190c55d0b?w=400',
      description:
          'The Monstera Deliciosa, also known as the Swiss Cheese Plant, is famous for its unique leaf perforations. It thrives in indirect light and adds a tropical feel to any room.',
      rating: 4.8,
    ),
    Plant(
      id: '2',
      name: 'Snake Plant',
      category: 'Indoor',
      price: 29.99,
      imageUrl:
          'https://images.unsplash.com/photo-1593482892540-55c0e0a0a49e?w=400',
      description:
          'The Snake Plant is one of the most tolerant houseplants. It filters indoor air and converts CO2 to oxygen at night, making it perfect for bedrooms.',
      rating: 4.6,
    ),
    Plant(
      id: '3',
      name: 'Peace Lily',
      category: 'Indoor',
      price: 34.99,
      imageUrl:
          'https://images.unsplash.com/photo-1593691509543-c55fb32d8de5?w=400',
      description:
          'The Peace Lily is an elegant plant with glossy dark green leaves and beautiful white flowers. It purifies the air and thrives in low light conditions.',
      rating: 4.7,
    ),
    Plant(
      id: '4',
      name: 'Aloe Vera',
      category: 'Succulents',
      price: 19.99,
      imageUrl:
          'https://images.unsplash.com/photo-1509423350716-97f9360b4e09?w=400',
      description:
          'Aloe Vera is a succulent plant known for its medicinal properties. Its gel soothes burns and skin irritations. Easy to care for and drought-tolerant.',
      rating: 4.5,
    ),
    Plant(
      id: '5',
      name: 'Rubber Plant',
      category: 'Indoor',
      price: 39.99,
      imageUrl:
          'https://images.unsplash.com/photo-1600411833196-7c1f6b1a8b90?w=400',
      description:
          'The Rubber Plant (Ficus elastica) features bold, shiny, dark green leaves that add an instant tropical, sophisticated vibe to any interior corner.',
      rating: 4.7,
    ),
    Plant(
      id: '6',
      name: 'Fiddle Leaf Fig',
      category: 'Indoor',
      price: 59.99,
      imageUrl:
          'https://images.unsplash.com/photo-1459411552884-841db9b3cc2a?w=400',
      description:
          'The Fiddle Leaf Fig is a stunning indoor tree with large, violin-shaped leaves. It makes a bold statement in any room and loves bright indirect light.',
      rating: 4.9,
    ),
  ];

  /// Returns plants filtered by the selected category
  List<Plant> get filteredPlants {
    if (_selectedCategoryIndex == 0) return allPlants; // "All" selected
    final category = categories[_selectedCategoryIndex];
    return allPlants.where((plant) => plant.category == category).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: softCream,
      // ── Body ──
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),

              // ── Header greeting ──
              Text(
                'Hello, Plant Lover! 👋',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey.shade500,
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                'Find your',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: darkGreen,
                ),
              ),
              const Text(
                'favorite plant',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: darkGreen,
                ),
              ),
              const SizedBox(height: 20),

              // ── Search bar ──
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.shade100,
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: TextField(
                  decoration: InputDecoration(
                    hintText: 'Search plants...',
                    hintStyle: TextStyle(
                      color: Colors.grey.shade400,
                      fontSize: 14,
                    ),
                    prefixIcon: const Icon(
                      Icons.search_rounded,
                      color: sageGreen,
                    ),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 14,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // ── Categories title ──
              const Text(
                'Categories',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: darkGreen,
                ),
              ),
              const SizedBox(height: 12),

              // ── Category chips (horizontal scroll) ──
              SizedBox(
                height: 42,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: categories.length,
                  itemBuilder: (context, index) {
                    final isSelected = index == _selectedCategoryIndex;
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          _selectedCategoryIndex = index;
                        });
                      },
                      child: Container(
                        margin: const EdgeInsets.only(right: 10),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 10,
                        ),
                        decoration: BoxDecoration(
                          color: isSelected ? sageGreen : Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: isSelected
                              ? []
                              : [
                                  BoxShadow(
                                    color: Colors.grey.shade100,
                                    blurRadius: 4,
                                    offset: const Offset(0, 2),
                                  ),
                                ],
                        ),
                        child: Text(
                          categories[index],
                          style: TextStyle(
                            color: isSelected ? Colors.white : darkGreen,
                            fontWeight:
                                isSelected ? FontWeight.w600 : FontWeight.normal,
                            fontSize: 14,
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 24),

              // ── Popular Plants header ──
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Popular Plants',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: darkGreen,
                    ),
                  ),
                  TextButton(
                    onPressed: () {},
                    child: const Text(
                      'See All',
                      style: TextStyle(
                        fontSize: 14,
                        color: sageGreen,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),

              // ── Plant product grid ──
              GridView.builder(
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 0.72,
                ),
                itemCount: filteredPlants.length,
                itemBuilder: (context, index) {
                  final plant = filteredPlants[index];
                  return _buildPlantCard(plant);
                },
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),

      // ── Bottom Navigation Bar ──
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.shade200,
              blurRadius: 10,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: _bottomNavIndex,
          onTap: (index) {
            setState(() {
              _bottomNavIndex = index;
            });
          },
          backgroundColor: Colors.white,
          selectedItemColor: sageGreen,
          unselectedItemColor: Colors.grey.shade400,
          type: BottomNavigationBarType.fixed,
          showSelectedLabels: true,
          showUnselectedLabels: true,
          elevation: 0,
          selectedFontSize: 12,
          unselectedFontSize: 12,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.home_rounded),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.search_rounded),
              label: 'Search',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.favorite_rounded),
              label: 'Favorites',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person_rounded),
              label: 'Profile',
            ),
          ],
        ),
      ),
    );
  }

  /// Builds a single plant product card for the grid
  Widget _buildPlantCard(Plant plant) {
    return GestureDetector(
      onTap: () {
        // Navigate to product details with the plant data
        Navigator.pushNamed(context, '/product', arguments: plant);
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.shade100,
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Plant image
            ClipRRect(
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
              child: Image.network(
                plant.imageUrl,
                height: 140,
                width: double.infinity,
                fit: BoxFit.cover,
                // Fallback when image fails to load
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                    height: 140,
                    color: sageGreen.withOpacity(0.1),
                    child: const Center(
                      child: Icon(
                        Icons.eco_rounded,
                        color: sageGreen,
                        size: 40,
                      ),
                    ),
                  );
                },
              ),
            ),

            // Plant info
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Plant name
                    Text(
                      plant.name,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: darkGreen,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 3),

                    // Category
                    Text(
                      plant.category,
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey.shade500,
                      ),
                    ),

                    const Spacer(),

                    // Price and add button row
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '\$${plant.price.toStringAsFixed(2)}',
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: sageGreen,
                          ),
                        ),
                        Container(
                          width: 32,
                          height: 32,
                          decoration: BoxDecoration(
                            color: sageGreen,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(
                            Icons.add,
                            color: Colors.white,
                            size: 18,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
