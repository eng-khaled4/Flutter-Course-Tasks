import 'package:flutter/material.dart';

/// Welcome Screen - The first screen users see when opening Leafy
class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  // Color constants
  static const Color sageGreen = Color(0xFF8A9A5B);
  static const Color softCream = Color(0xFFF7F6EF);
  static const Color darkGreen = Color(0xFF344735);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // ── Background plant image (top 65%) ──
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.65,
            width: double.infinity,
            child: Image.network(
              'https://images.unsplash.com/photo-1459411552884-841db9b3cc2a?w=800',
              fit: BoxFit.cover,
              // Show a placeholder while the image loads
              loadingBuilder: (context, child, loadingProgress) {
                if (loadingProgress == null) return child;
                return Container(
                  color: sageGreen.withOpacity(0.2),
                  child: const Center(
                    child: CircularProgressIndicator(color: sageGreen),
                  ),
                );
              },
              // Show a fallback if the image fails to load
              errorBuilder: (context, error, stackTrace) {
                return Container(
                  color: sageGreen.withOpacity(0.15),
                  child: const Center(
                    child: Icon(Icons.eco_rounded, size: 80, color: sageGreen),
                  ),
                );
              },
            ),
          ),

          // ── Gradient overlay for smooth transition ──
          Positioned(
            top: MediaQuery.of(context).size.height * 0.35,
            left: 0,
            right: 0,
            height: MediaQuery.of(context).size.height * 0.30,
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    softCream.withOpacity(0.0),
                    softCream.withOpacity(0.6),
                    softCream,
                  ],
                ),
              ),
            ),
          ),

          // ── Bottom content section ──
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              color: softCream,
              padding: const EdgeInsets.fromLTRB(28, 0, 28, 40),
              child: SafeArea(
                top: false,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // App logo and name
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: sageGreen.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(
                            Icons.eco_rounded,
                            color: sageGreen,
                            size: 28,
                          ),
                        ),
                        const SizedBox(width: 10),
                        const Text(
                          'Leafy',
                          style: TextStyle(
                            fontSize: 30,
                            fontWeight: FontWeight.bold,
                            color: darkGreen,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // Welcome title
                    const Text(
                      'Bring Nature\nInto Your Home',
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.w800,
                        color: darkGreen,
                        height: 1.2,
                      ),
                    ),
                    const SizedBox(height: 12),

                    // Description
                    Text(
                      'Discover the perfect indoor plants to transform your living space into a green paradise.',
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.grey.shade600,
                        height: 1.5,
                      ),
                    ),
                    const SizedBox(height: 32),

                    // Get Started button
                    SizedBox(
                      width: double.infinity,
                      height: 56,
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.pushNamed(context, '/login');
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: sageGreen,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                        child: const Text(
                          'Get Started',
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Already have an account link
                    Center(
                      child: TextButton(
                        onPressed: () {
                          Navigator.pushNamed(context, '/login');
                        },
                        child: RichText(
                          text: TextSpan(
                            text: 'Already have an account? ',
                            style: TextStyle(
                              color: Colors.grey.shade500,
                              fontSize: 14,
                            ),
                            children: const [
                              TextSpan(
                                text: 'Login',
                                style: TextStyle(
                                  color: sageGreen,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
